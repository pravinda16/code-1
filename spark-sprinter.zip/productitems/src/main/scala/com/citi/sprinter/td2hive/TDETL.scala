package com.citi.sprinter.td2hive

//  Author: Simon(jy44875) Time: 2017-01-23 ~ 2017-03-23

import com.citi.sprinter.core._
import com.citi.sprinter.util._
import java.text.SimpleDateFormat
import java.util.Calendar

abstract class MTD(tdc: TDC) extends TETLM {
  val ssc    = tdc.r.sparkSSC
  val db     = tdc.s.sourceTable.split("\\.")(0).toUpperCase()
  val tb     = tdc.s.sourceTable.split("\\.")(1).toUpperCase()
  val fltexp = tdc.x.sourceTableFilterExpr
  val hivedb = tdc.s.targetTable.split("\\.")(0).toLowerCase()
  val hivetb = tdc.s.targetTable.split("\\.")(1).toLowerCase()
  val dbpath = tdc.s.targetTableLocation.getOrElse( HV.getDBFolder(ssc, hivedb) ) 
  val tbpath = s"$dbpath/$hivetb"
  val flfmt  = tdc.s.targetTableFileFormat
  val ampn   = tdc.tdcc.numAMP.intValue
  val ideapd = tdc.r.ideaParallelDegree
  val maxpd  = tdc.r.sparkMaxParallelDegree
  val sparkpd= tdc.r.sparkParallelDegree.toInt
  val jdbcfs = tdc.r.sourceTableJDBCFetchSize
  val dsTCI  = DS.getTCI(tdc)
  val retenp = tdc.s.targetTablePartitionRetentionPolicy
  val unnest = tdc.tdcc.depth == 0
  val flBkF  = tdc.tdcc.flBkF
  val nodataE =  if( !tdc.x.sourceTableDisableNoDataException.isEmpty && tdc.x.sourceTableDisableNoDataException.get == "ON") false else true
  
  

  def dumpTDCC(inf:Boolean, flbak:Boolean): TDCC = {
    val nbakf=if(inf) tdc.tdcc.flBkF else flbak
    TDCC(tdc.tdcc.numNodes,
      tdc.tdcc.tabMB,
      tdc.tdcc.tabRNum,
      tdc.tdcc.tabSkew,
      tdc.tdcc.tabPIC,
      tdc.tdcc.numAMP,
      tdc.tdcc.ampMin,
      tdc.tdcc.ampMax,
      tdc.tdcc.ampAvg,
      tdc.tdcc.tbCols,
      tdc.tdcc.dtCols,
      tdc.tdcc.tsCols,
      tdc.tdcc.depth + 1, nbakf)
  }
  
  def getMinYMD(): String = {
      val fmtYMD = new SimpleDateFormat("yyyy-MM-dd")
      val cal = Calendar.getInstance(); cal.setTime(fmtYMD.parse(tdc.s.sprinterAsOfDate)); cal.add(Calendar.DATE, -1 * (retenp-1).intValue)
      val mindt=cal.getTime;val minYMD=fmtYMD.format(mindt)
      minYMD
  }

 def cleanExpiredData(ptkl: String) = {
    if(!flBkF && retenp > 0L ) {
      val fmtYMD = new SimpleDateFormat("yyyy-MM-dd"); val minYMD = getMinYMD(); val mindt  = fmtYMD.parse(minYMD)
      val fixdates  = HV.getExpiredDate(ssc, hivetb, ptkl, minYMD)  //01    
      val dfprts = ssc.sql(s"SHOW PARTITIONS $hivetb").collect()
      
      //clean up
      dfprts.map{ row =>
        val pts=row.get(0).toString(); val ptvYMD=HT.getYMDFromPTS(ptkl, pts);  val dtYMD = TL.tryParse(fmtYMD, ptvYMD)      
        if( dtYMD.before(mindt) ) {
          HV.rmHDFSFolder(ssc, s"$tbpath/$pts")
          val hiveptexpr = HT.getPTEFromPTS(pts); val sqldrop = s"ALTER TABLE $hivetb DROP IF EXISTS PARTITION ($hiveptexpr)"
          LG.info(s"minYMD: $minYMD, ptvYMD: $ptvYMD sqldrop: $sqldrop");ssc.sql(sqldrop)         
        }else {
          LG.info(s"minYMD: $minYMD, ptvYMD: $ptvYMD keep  $pts")
        }
      }
 
      //clean up fix 02
      LG.info( s"minYMDx: $minYMD, dates:" + fixdates.mkString(",") )
      dfprts.map{ row =>
        val pts=row.get(0).toString(); val ptvYMD=HT.getYMDFromPTS(ptkl, pts);  val dtYMD = TL.tryParse(fmtYMD, ptvYMD)    
        if( dtYMD.before(mindt)  && fixdates.indexOf(ptvYMD) >= 0 ) {
          val expr = s"${ptkl}=${ptvYMD}"; val indx = pts.indexOf(expr)
          LG.info(s"expr: $expr, pts: $pts ")
          if( indx >= 0) {
            val path=pts.substring(0, indx + expr.length )
            val hdfspath = s"$tbpath/$path"; LG.info(s"minYMDx: $minYMD, ptvYMD: $ptvYMD, hdfspath: $hdfspath ")
            HV.rmHDFSFolder(ssc, hdfspath)
          }       
        }
      }
    } 

  }// end cleanExpiredData
}


class TDETL(s: SSSC, x: SSXC) extends TETLS {
  val tb     = s.sourceTable.split("\\.")(1).toUpperCase()
  val hivedb = s.targetTable.split("\\.")(0).toLowerCase()
  val hivetb = s.targetTable.split("\\.")(1).toLowerCase()

  def getm(tdc: TDC): TETLM = {
    val rp = tdc.s.targetTablePartitionRetentionPolicy
    val mm = if (s.targetTablePartitionColumn.isEmpty) {
      if( tdc.r.sparkParallelDegree >= tdc.r.ideaParallelDegree) new MNS(tdc) else {
        if( tdc.r.sparkSNum > 1 ) new MNH(tdc) else new MNL(tdc)
      }
    } else {
      if( !HV.tbExists(tdc.r.sparkSSC, hivetb) || HV.tbNoData(tdc.r.sparkSSC, hivetb) ) {
        LG.info("TDETL table not exists or table emtpy"); new MPCore(tdc) 
      }else {
        val ls = tdc.x.targetTableLoadingStrategory
        val ss = tdc.x.sourceTableNewColumnsName.filter( r => r.toUpperCase() == tdc.s.targetTablePartitionColumn.get.toUpperCase ).length == 1 
         
        if( ls == "FULL_LOADING" && rp == 0L ) {
          LG.info("TDETL MPF FULL_LOADING");           new MPDFull(tdc)
        }else if ( !ss && ls == "INCREMENTAL_LOADING_CNT"){
           LG.info("TDETL INCREMENTAL_LOADING_CNT");   new MPDCnt(tdc)
        }else if ( ls == "TRUNCATE_LOADING"){
           LG.info("TDETL TRUNCATE_LOADING");          new MPDDrp(tdc)
        }else{
          LG.info("TDETL DEFAULT");                    new MPCore(tdc)
        }
      }
    }
    mm
  }

  def r() = {
    val sw = SW().start
    val tdc = new TDP(s, x).p()
    sw.awpLog("SPRINTER INIT time:")

    tdc.r.sparkSSC.sql(s"USE  $hivedb")
    val m = getm(tdc)
    m.r()

    val benchmark=50; val speed=tdc.tdcc.tabMB/sw.seconds(); val ratio= math.ceil(100.0 * ( speed-benchmark ) / benchmark)
    val sx = s"speed: $speed mb/s (benchmark: $benchmark, ration: ${ratio}%), table: $tb, amp: ${tdc.tdcc.numAMP}, numNodes: ${tdc.tdcc.numNodes},table_size: ${tdc.tdcc.tabMB} MB ,parallel: ${tdc.r.sparkParallelDegree}, file_format: ${tdc.s.targetTableFileFormat}"
    sw.awpLog("SPRINTER ETL  time:", sx )
    
    CTRK.ended()
    tdc.r.sc.stop()
  }
  
}