package com.citi.sprinter.mm2hive

//  Author: Simon(jy44875) Time: 2017-05-20 ~ 2017-06-03


import com.citi.sprinter.core._

case class MMCC (
    val tabBK:     Long,
    val tabMB:     Long,
    val partSkew:  Int,
    val partMin:   Long,
    val partMax:   Long,
    val partAvg:   Long,
    val partNum:   Long,
    val aggNum:    Long,
    val tbCols:    Array[String],
    val dtCols:    Array[String],
    val tsCols:    Array[String],
    val depth:     Int,
    val flBkF:     Boolean
);

case class MMC(override val s:SSSC,  override val x:SSXC, override val r:SSRC, val mmcc: MMCC) extends SSBC(s, x, r)