package com.citi.sprinter.mm2hive

//  Author: Simon(jy44875) Time: 2017-05-17 ~ 2017-06-03

import com.citi.sprinter.core._
import com.citi.sprinter.util._
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.DataFrame

class MPDCnt(mmc: MMC) extends MMM(mmc) {
  val allPtkl = mmc.s.targetTablePartitionColumn.get.toLowerCase
  val allPtku = mmc.s.targetTablePartitionColumn.get.toUpperCase
  val aptkl   = allPtkl.split(",").map( r => r.trim() ) 
  val aptku   = allPtku.split(",").map( r => r.trim() ) 

  //2017-07-02
  val _dtIdx  = mmc.s.targetTablePartitionDateColumnIndex
  val dtIdx   = if( _dtIdx < 0 || _dtIdx > aptkl.length ) aptkl.length - 1 else _dtIdx - 1
  val tptkl   = aptkl( dtIdx )
  val tptku   = aptku( dtIdx )
  
  def r(): Unit = {
    LG.info("In MPDCnt"); val sw = SW().start
    
    val where = if( fltexp.isEmpty) "" else s" WHERE ${fltexp.get}"
    val colsx = if( aptkl.length <= 1 ) "" else aptku.filter( r => r != tptku ).mkString("," ) +  "," 
    val sqlora = s"""( SELECT $colsx DATE_FORMAT($tptku, '%Y-%m-%d') AS $tptku,  TO_CHAR( COUNT(*) ) AS CNT FROM $db.$tb $where GROUP BY $colsx DATE_FORMAT($tptku, '%Y-%m-%d') ) y"""
    val optora = CUTL.getOption(mmc.s, sqlora, 1000); LG.debug(sqlora)
    val dfora  = ssc.read.format("jdbc").options(optora).load().cache()
    dfora.registerTempTable("tdtab123"); val mindt  = ssc.sql(s"SELECT MIN($tptku) FROM tdtab123").first().getString(0)
    LG.info(s"mindt: $mindt")
    
    val sqlhiv = s"SELECT  $allPtku, CAST( COUNT(*) AS STRING) AS CNT FROM $hivetb WHERE $tptku >= '$mindt' GROUP BY $allPtku"
    val dfhiv  = ssc.sql(sqlhiv).cache(); LG.debug(sqlhiv)
    val dfnew = dfora.except(dfhiv); dfnew.cache(); dfnew.printSchema(); dfnew.show(10000,false)
    val dstct = dfnew.count(); sw.debug(s"SPRINTER CNT  time: dstct: $dstct")
    val rows  = dfnew.collect(); dfhiv.unpersist(); dfora.unpersist(); dfnew.unpersist()
    
    if( dstct <= 0 ) {
      LG.awpLog("NO NEW DATA")
      cleanExpiredData(tptkl)
    } else {
      val fExpr = rows.map { row =>
        val rval=(0 to (aptku.length-2) ).map{ i => 
          val tmpv = row.getString(i)
          val tmpn = aptku(i)
          s"$tmpn = '$tmpv' "
        } 
        val dtv = row.getString(aptku.length-1)
        val dte1 = rval.mkString(" AND ")
        val dte2 = s"$tptku = TO_DATE('$dtv', 'YYYY-MM-DD')" 
        if  (dte1.isEmpty() ) dte2 else s"( $dte1  AND  $dte2 )"
      }.mkString(" OR \n")
      val nw = if( dstct < 186 ) s"( $fExpr )" else ""; LG.info(s"LAST UPDATE TIME, FILTER EXPRESS: $nw")
      val nx = CUTL.dumpSSXC(mmc.x, nw)
      val norcl = MMC(mmc.s , nx, mmc.r, dumpMMCC(true, true))
      val m = new MPCore(norcl)
      m.r()
    }
  }
}