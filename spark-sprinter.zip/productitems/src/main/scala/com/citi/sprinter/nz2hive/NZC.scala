package com.citi.sprinter.nz2hive

//  Author: Simon(jy44875) Time: 2017-05-17 ~ 2017-05-19

import com.citi.sprinter.core._

case class NZCC (
    val tabBK:     Long,
    val tabMB:     Long,
    val sliceSkew: Int,
    val sliceMin:  Long,
    val sliceMax:  Long,
    val sliceAvg:  Long,
    val sliceNum:  Long,
    val tbCols:    Array[String],
    val dtCols:    Array[String],
    val tsCols:    Array[String],
    val depth:     Int,
    val flBkF:     Boolean
);

case class NZC(override val s:SSSC,  override val x:SSXC, override val r:SSRC, val nzcc: NZCC) extends SSBC(s, x, r)