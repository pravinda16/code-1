package com.citi.sprinter.nz2hive

//  Author: Simon(jy44875) Time: 2017-05-17 ~ 2017-05-18

import com.citi.sprinter.core._
import com.citi.sprinter.util._
import java.text.SimpleDateFormat
import java.util.Calendar

abstract class MNZ(nzc: NZC) extends TETLM {
  val ssc    = nzc.r.sparkSSC
  val db     = nzc.s.sourceTable.split("\\.")(0).toUpperCase()
  val tb     = nzc.s.sourceTable.split("\\.")(1).toUpperCase()
  val fltexp = nzc.x.sourceTableFilterExpr
  val hivedb = nzc.s.targetTable.split("\\.")(0).toLowerCase()
  val hivetb = nzc.s.targetTable.split("\\.")(1).toLowerCase()
  val dbpath = nzc.s.targetTableLocation.getOrElse( HV.getDBFolder(ssc, hivedb) ) 
  val tbpath = s"$dbpath/$hivetb"
  val flfmt  = nzc.s.targetTableFileFormat
  val nzsn   = nzc.nzcc.sliceNum.intValue
  val maxpd  = nzc.r.sparkMaxParallelDegree
  val ideapd = nzc.r.ideaParallelDegree
  val sparkpd= nzc.r.sparkParallelDegree.toInt
  val nsplt  = math.ceil(1.0 * nzc.r.ideaParallelDegree/nzc.r.sparkParallelDegree).intValue
  val jdbcfs = nzc.r.sourceTableJDBCFetchSize
  val dsTCI  = DS.getTCI(nzc)
  val retenp = nzc.s.targetTablePartitionRetentionPolicy
  val unnest = nzc.nzcc.depth == 0
  val flBkF  = nzc.nzcc.flBkF
  val nodataE =  if( !nzc.x.sourceTableDisableNoDataException.isEmpty && nzc.x.sourceTableDisableNoDataException.get == "ON") false else true

  def dumpNZCC(inf:Boolean, flbak:Boolean): NZCC = {
    val nbakf=if(inf) nzc.nzcc.flBkF else flbak
    NZCC(nzc.nzcc.tabBK,
      nzc.nzcc.tabMB,
      nzc.nzcc.sliceSkew,
      nzc.nzcc.sliceMin,
      nzc.nzcc.sliceMax,
      nzc.nzcc.sliceAvg,
      nzc.nzcc.sliceNum,
      nzc.nzcc.tbCols,
      nzc.nzcc.dtCols,
      nzc.nzcc.tsCols,
      nzc.nzcc.depth + 1, nbakf)
  }
  
  def getMinYMD(): String = {
      val fmtYMD = new SimpleDateFormat("yyyy-MM-dd")
      val cal = Calendar.getInstance(); cal.setTime(fmtYMD.parse(nzc.s.sprinterAsOfDate)); cal.add(Calendar.DATE, -1 * (retenp-1).intValue)
      val mindt=cal.getTime;val minYMD=fmtYMD.format(mindt)
      minYMD
  }

 def cleanExpiredData(ptkl: String) = {
    if(!flBkF && retenp > 0L ) {
      val fmtYMD = new SimpleDateFormat("yyyy-MM-dd"); val minYMD = getMinYMD(); val mindt  = fmtYMD.parse(minYMD)
      val fixdates  = HV.getExpiredDate(ssc, hivetb, ptkl, minYMD)  //01    
      val dfprts = ssc.sql(s"SHOW PARTITIONS $hivetb").collect()
      
      //clean up
      dfprts.map{ row =>
        val pts=row.get(0).toString(); val ptvYMD=HT.getYMDFromPTS(ptkl, pts);  val dtYMD = TL.tryParse(fmtYMD, ptvYMD)      
        if( dtYMD.before(mindt) ) {
          HV.rmHDFSFolder(ssc, s"$tbpath/$pts")
          val hiveptexpr = HT.getPTEFromPTS(pts); val sqldrop = s"ALTER TABLE $hivetb DROP IF EXISTS PARTITION ($hiveptexpr)"
          LG.info(s"minYMD: $minYMD, ptvYMD: $ptvYMD sqldrop: $sqldrop");ssc.sql(sqldrop)         
        }else {
          LG.info(s"minYMD: $minYMD, ptvYMD: $ptvYMD keep $pts")
        }
      }
 
      //clean up fix 02
      LG.info( s"minYMDx: $minYMD, dates:" + fixdates.mkString(",") )
      dfprts.map{ row =>
        val pts=row.get(0).toString(); val ptvYMD=HT.getYMDFromPTS(ptkl, pts);  val dtYMD = TL.tryParse(fmtYMD, ptvYMD)    
        if( dtYMD.before(mindt)  && fixdates.indexOf(ptvYMD) >= 0 ) {
          val expr = s"${ptkl}=${ptvYMD}"; val indx = pts.indexOf(expr)
          LG.info(s"expr: $expr, pts: $pts ")
          if( indx >= 0) {
            val path=pts.substring(0, indx + expr.length )
            val hdfspath = s"$tbpath/$path"; LG.info(s"minYMDx: $minYMD, ptvYMD: $ptvYMD, hdfspath: $hdfspath ")
            HV.rmHDFSFolder(ssc, hdfspath)
          }       
        }
      }
    } 

  }// end cleanExpiredData
}


class NZETL(s: SSSC, x: SSXC) extends TETLS {
  val tb     = s.sourceTable.split("\\.")(1).toUpperCase()
  val hivedb = s.targetTable.split("\\.")(0).toLowerCase()
  val hivetb = s.targetTable.split("\\.")(1).toLowerCase()

  def getm(nzc: NZC): TETLM = {
    val rp = nzc.s.targetTablePartitionRetentionPolicy
    val mm = if (s.targetTablePartitionColumn.isEmpty) {
      val nsplt  = math.ceil(1.0 * nzc.r.ideaParallelDegree/nzc.r.sparkParallelDegree).intValue
      LG.info(s"nsplt: $nsplt")
      if (nsplt > 1) new MNL(nzc) else new MNS(nzc)
    } else {
      if( !HV.tbExists(nzc.r.sparkSSC, hivetb) || HV.tbNoData(nzc.r.sparkSSC, hivetb) ) {
        LG.info("TDETL table not exists or table emtpy"); new MPCore(nzc) 
      }else {
        val ls = nzc.x.targetTableLoadingStrategory
        val ss = nzc.x.sourceTableNewColumnsName.filter( r => r.toUpperCase() == nzc.s.targetTablePartitionColumn.get.toUpperCase ).length == 1 
         
        if( ls == "FULL_LOADING" && rp == 0L ) {
          LG.info("TDETL MPF FULL_LOADING");           new MPDFull(nzc)
        }else if ( !ss && ls == "INCREMENTAL_LOADING_CNT"){
           LG.info("TDETL INCREMENTAL_LOADING_CNT");   new MPDCnt(nzc)
        }else if ( ls == "TRUNCATE_LOADING"){
           LG.info("TDETL TRUNCATE_LOADING");          new MPDDrp(nzc)
        }else{
          LG.info("TDETL DEFAULT");                    new MPCore(nzc)
        }
      }
    }
    mm
  }

  def r() = {
    val sw = SW().start
    val nzc = new NZP(s, x).p()
    sw.awpLog("SPRINTER INIT time:")

    nzc.r.sparkSSC.sql(s"USE  $hivedb")
    val m = getm(nzc)
    m.r()

    val benchmark=50; val speed=nzc.nzcc.tabMB/sw.seconds(); val ratio= math.ceil(100.0 * ( speed-benchmark ) / benchmark)
    val sx = s"speed: $speed mb/s (benchmark: $benchmark, ration: ${ratio}%), table: $tb, sliceNum: ${nzc.nzcc.sliceNum},table_size: ${nzc.nzcc.tabMB} MB ,parallel: ${nzc.r.sparkParallelDegree}, file_format: ${nzc.s.targetTableFileFormat}"
    sw.awpLog("SPRINTER ETL  time:", sx )
    
    CTRK.ended()
    nzc.r.sc.stop()
  }
  
}