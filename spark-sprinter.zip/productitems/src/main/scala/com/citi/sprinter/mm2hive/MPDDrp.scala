package com.citi.sprinter.mm2hive

//  Author: Simon(jy44875) Time: 2017-05-17 ~ 2017-06-03

import com.citi.sprinter.core._
import com.citi.sprinter.util._
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.DataFrame

class MPDDrp(nzc: MMC) extends MMM(nzc) {
  def r(): Unit = {
    LG.info("In MPDDrp")
    var bkl: String = ""; val bkf = true
    if(bkf) { var bkf = HV.bkETTable(ssc, hivetb); if( bkf.isEmpty) throw new SSE(s"Failed to backup table: $hivetb"); bkl=bkf.get } 
    try {
      val norcl = MMC(nzc.s , nzc.x, nzc.r, dumpMMCC(false, true)); val m = new MPCore(norcl); m.r()
    } catch {
      case ex: Exception => { if(bkf) HV.rsETTable(ssc, hivetb, bkl); throw ex }
    }
    if(bkf) HV.rmETTableBk(ssc, bkl, hivetb)    
  }
}