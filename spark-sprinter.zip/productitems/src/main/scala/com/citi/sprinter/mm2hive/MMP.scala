package com.citi.sprinter.mm2hive

//  Author: Simon(jy44875) Time: 2017-05-20 ~ 2017-06-03

import java.sql.{Connection,DriverManager}
import com.citi.sprinter.core._
import com.citi.sprinter.util._
import org.apache.spark.{ SparkContext, SparkConf }
import org.apache.spark.sql.hive.HiveContext

class MMP(s: SSSC, x: SSXC) extends TETLP {
  val db = s.sourceTable.split("\\.")(0)
  val tb = s.sourceTable.split("\\.")(1)
  var udb= db
  var utabs:Array[String]=Array.empty[String]
  
  def createDC() :Connection = {
    val driver = "com.mysql.jdbc.Driver"
    var connection: Connection = null
    var times = 0
    var flag = 0
    val pwd  = if ( s.sourceDatabasePassword.get == "_PWD_NA_" ) null else s.sourceDatabasePassword.get

    while ( times <= 3 && flag == 0) {
      try {
        Class.forName(driver)
        times = times + 1
        connection = DriverManager.getConnection(s.sourceDatabaseURL, s.sourceDatabaseUser, pwd) 
        flag = flag + 1
      } catch {
        case e: Exception => e.printStackTrace
      } 
    }
    
    if( flag > 0 ) connection else throw new SSE("Failed to connect database")
  }
  
  
  def checkTE(conn: Connection): Boolean = {
    var cnt: Long = 0
    val sql = s"SELECT COUNT(1) as CNT FROM information_schema.TABLES WHERE TABLE_SCHEMA='$db' AND TABLE_NAME='$tb' and TABLE_TYPE LIKE '%TABLE%' ";    LG.debug(sql)
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        cnt = rs.getBigDecimal("CNT").longValue()
      }
      rs.close()
      if( cnt == 1) true else false
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw e
      }
    }
  }
  
  def checkVE(conn: Connection): Boolean = {
    var cnt: Long = 0
    val sql = s"SELECT COUNT(1) as CNT FROM information_schema.TABLES WHERE TABLE_SCHEMA='$db'AND TABLE_NAME='$tb' and TABLE_TYPE LIKE '%VIEW%' ";    LG.debug(sql)
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        cnt = rs.getBigDecimal("CNT").longValue()
      }
      rs.close()
      if( cnt == 1) true else false
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw e
      }
    }
  }
  
  //Mem size now
  def getTS(conn: Connection): (Long,Long) = {
    var mb: Long = 0
    var bk: Long = 0
    val sql = s"""
SELECT IFNULL(ROUND(sum(memory_use)/1024/1024, 0), 1) AS MB, COUNT(*) AS BK
FROM   INFORMATION_SCHEMA.TABLE_STATISTICS
WHERE  partition_type='Master' AND database_name='$db' AND  table_name = '$tb' """
    LG.debug(sql)
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        bk = rs.getBigDecimal("BK").longValue()
        mb = rs.getBigDecimal("MB").longValue() 
      }
      rs.close()
      (bk,mb)
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get table size, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }

  def geAggNum(conn: Connection): Int = {
    var cnt: Int = 0
    val sql = s"SELECT COUNT(*) AS CNT FROM INFORMATION_SCHEMA.AGGREGATORS WHERE STATE = 'online' "
    LG.debug(sql)
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        cnt = rs.getInt("CNT")
      }
        
      rs.close()
      cnt
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get table size, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }
 
  def getTCols(conn: Connection): Array[String] = {
    var cols = scala.collection.mutable.ArrayBuffer.empty[String]
    val sql = s"""
SELECT ORDINAL_POSITION, COLUMN_NAME, DATA_TYPE 
FROM   INFORMATION_SCHEMA.COLUMNS 
WHERE  TABLE_SCHEMA='$db' AND  TABLE_NAME='$tb'
ORDER BY ORDINAL_POSITION  """
    LG.debug(sql)
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        cols += rs.getString("COLUMN_NAME").trim()
      }
      rs.close()
      cols.toArray
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get table cols, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }
  
  def getTDateCols(conn: Connection): Array[String] = {
    var cols = scala.collection.mutable.ArrayBuffer.empty[String]
    val tabs = utabs.map( "'" + _ + "'").mkString(",")
    val sql = s"""
SELECT ORDINAL_POSITION, COLUMN_NAME, DATA_TYPE 
FROM   INFORMATION_SCHEMA.COLUMNS 
WHERE  TABLE_SCHEMA='$db' AND  TABLE_NAME='$tb' AND DATA_TYPE = 'date'
ORDER BY ORDINAL_POSITION   """
    LG.debug(sql)
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        cols += rs.getString("COLUMN_NAME").trim()
      }
      rs.close()
      cols.toArray
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get date cols, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }

  def getTTimestampCols(conn: Connection): Array[String] = {
    var cols = scala.collection.mutable.ArrayBuffer.empty[String]
    val tabs = utabs.map( "'" + _ + "'").mkString(",")
    val sql = s"""
SELECT ORDINAL_POSITION, COLUMN_NAME, DATA_TYPE 
FROM   INFORMATION_SCHEMA.COLUMNS 
WHERE  TABLE_SCHEMA='$db' AND  TABLE_NAME='$tb' AND DATA_TYPE = 'datetime'
ORDER BY ORDINAL_POSITION  """
    LG.debug(sql)
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        cols += rs.getString("COLUMN_NAME").trim()
      }
      rs.close()
      cols.toArray
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get timestamp cols, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }

  def getMMCC(): MMCC = {
    val sw = SW().start
    val conn    = createDC()
    sw.debug("TDCC createDC")
    
    if( !checkTE(conn) ) {
      conn.close()
      throw new SSE(s"table does not exists or underlying table does not exist: $tb ")
    }
    sw.debug("TDCC checkTE")
    
    val ts   = getTS(conn)
    sw.debug("TDCC getTS")
    val aggNum   = geAggNum(conn)
    
    
    val tbcols = getTCols(conn)
    val dtCols = getTDateCols(conn)
    val tsCols = getTTimestampCols(conn)
    
    val tmpdt=dtCols.mkString(","); val tmpts=tsCols.mkString(",")
    LG.info(s"date_cols: $tmpdt, timestamp_cols: $tmpts") 
    
    var partSkew: Int = 0
    var partMin:  Long = 0
    var partMax:  Long = 0
    var partAvg:  Long = 0
    var partNum:  Long = 0
        
    val sql = s"""
SELECT
  COUNT(*)                                 AS  PARTNUM,
  MIN(ROWS)                                AS  PARTMIN,
  MAX(ROWS)                                AS  PARTMAX,
  ROUND(AVG(ROWS),0)                       AS  PARTAVG,
  ROUND(100 - AVG(ROWS)* 100/MAX(ROWS), 0) AS  PARTSKEW
FROM INFORMATION_SCHEMA.TABLE_STATISTICS
WHERE PARTITION_TYPE='MASTER' AND DATABASE_NAME='$db' AND  TABLE_NAME = '$tb'
"""
    try {
      val statement = conn.createStatement
      LG.debug(sql)
      val rs = statement.executeQuery(sql)
      while (rs.next) {
       partSkew = rs.getInt("PARTSKEW")
       partAvg  = rs.getLong("PARTAVG")
       partMin  = rs.getLong("PARTMIN")
       partMax  = rs.getLong("PARTMAX")
       partNum  = rs.getLong("PARTNUM")
      }
      rs.close()
      
      MMCC(ts._1, ts._2, partSkew, partMin, partMax, partAvg, partNum, aggNum, tbcols, dtCols, tsCols,  0, false)
    } catch {
      case e: Exception => {
        throw new SSE(s"unable to get table information 3, ${db}.${tb}, error: ${e.toString()}")
        throw e
      }
    }
  }
 
  def p(): MMC = {
    val mm = getMMCC()
    LG.debug(mm.toString())

    val mb = mm.tabMB.toInt
    val amb = Array[Int](64,  1024, 8*1024, 1024*16, 1024*64, 1024 *512, 1024 * 1024, 8 * 1024* 1024, 32 * 1024* 1024,Int.MaxValue)
    val spd = Array[Int](4,   8,    16,          32, 64,      128,        256,         512,            1024,           2048)
    val ccc = Array[Int](1,   2,    4,           4,  2,       2,          1,           1,              1,              1)
    val ddd = Array[Int](2,   2,    4,           8,  16,      16,         24,          24,             24,             24)
    val eee = Array[Int](2,   4,    8,          16,  16,      16,         16,          16,             16,             16)

    val sparkDriverMemory                     = TL.getOrFindTable("SPRINTER_X_DRIVER_MEMORY",    amb, ddd, mb)
    if( !CUTL.getOptionalEnv("SPRINTER_GET_DRIVER_MEMORY").isEmpty ) {
      println(s"ROWROW_DMM $sparkDriverMemory")
      System.exit(0)
    }
    
    val _sparkParallelDegree                  = CUTL.getOptionalEnvx("sparkParallelDegree").getOrElse("0").toInt
    
    val sparkMaxParallelDegree                = CUTL.getOptionalEnvx("SPRINTER_X_MAX_PARALLEL").getOrElse("64").toInt    
    val sparkExecutorCores                    = TL.getOrFindTable("SPRINTER_X_EXECUTOR_CORES",   amb, ccc, mb)
    val sparkExecutorMemory                   = TL.getOrFindTable("SPRINTER_X_EXECUTOR_MEMORY",  amb, eee, mb)
    val sourceTableJDBCFetchSize              = CUTL.getOptionalEnvx("SPRINTER_X_JDBC_FETCH_SIZE").getOrElse("10000").toInt
    val targetTableLoadingStrategory          = "INCREMENTAL_LOADING_CNT"
    val spark_colsotre_batch_size             = CUTL.getOptionalEnvx("SPRINTER_X_COLUMNARSTORAGE_BATCHSIZE").getOrElse("100000").toLong
          
    val sparkConf = new SparkConf()
    sparkConf.setAppName("SPRINTER_" + s.sprinterJobID + "_" + s.sprinterRunID)
    sparkConf.set("spark.driver.memory",                           s"${sparkDriverMemory}g")
    sparkConf.set("spark.executor.memory",                         s"${sparkExecutorMemory}g")
    sparkConf.set("spark.executor.cores",                          sparkExecutorCores.toString)
    sparkConf.set("spark.sql.inMemoryColumnarStorage.batchSize",   spark_colsotre_batch_size.toString)
    sparkConf.set("spark.ui.enabled",                              "false")
    sparkConf.set("spark.shuffle.memoryFraction",                  "0.5")
    sparkConf.set("spark.yarn.executor.memoryOverhead",            "4096")

    val instances = CUTL.getOptionalEnv("SPRINTER_X_EXECUTOR_INSTANCES")
    if (!instances.isEmpty) {
      sparkConf.set("spark.executor.instances", instances.get)
    }
    val sc  = new SparkContext(sparkConf)
    val sparkSSC = new HiveContext(sc)
    sparkSSC.setConf("spark.sql.parquet.compression.codec", x.targetTablecompressCodec)
    if( !s.targetTablePartitionColumn.isEmpty) HV.enableDP(sparkSSC)
    CTRK.inited()
  

    var sparkCNum:Int = 1
    var sparkSNum:Int = 0   
    if (mm.partMax > 0L) {
      val sz = 100
      val xcols = mm.tbCols.map( x => x + " AS " + x ).mkString(",")
      val sql = s"( SELECT $xcols FROM $db.$tb LIMIT $sz) A"
      val to = CUTL.getOption(s, sql, sourceTableJDBCFetchSize); LG.logSparkOption(to)
      val df = sparkSSC.read.format("jdbc").options(to).load()
      val rdd = df.rdd.map(_.toString())
      val aa = rdd.map(_.getBytes("UTF-8").length.toLong).reduce(_ + _) / sz
      val bb    = math.max(((aa * mm.partMax ) >> 20), 1)
      sparkCNum = math.max(2048/bb,   1).intValue()
      sparkSNum = math.ceil(bb /2048.0).intValue()
    }
    
    val ideaParallelDegree  = if( sparkSNum > 1) mm.partNum * sparkSNum else math.max(mm.partNum/sparkCNum,1)
    val sparkParallelDegree = if( _sparkParallelDegree > 0 ) _sparkParallelDegree else math.min( math.min(TL.findTab(amb, spd, mb), mm.aggNum * 8), sparkMaxParallelDegree) 
    
    LG.info(s"sparkExecutorCores: $sparkExecutorCores g; sparkExecutorMemory: $sparkExecutorMemory table: $mb MB")
    LG.info(s"mb: $mb aggNum: ${mm.aggNum} partNum: ${mm.partNum} sparkCNum: $sparkCNum; sparkSNum: $sparkSNum ideaParallelDegree: $ideaParallelDegree sparkParallelDegree: $sparkParallelDegree")
    
    val r = SSRC(
      sc                                       ,
      sparkSSC                                 ,
      sparkMaxParallelDegree                   ,
      sparkDriverMemory                        ,
      sparkExecutorCores                       ,
      sparkExecutorMemory                      ,
      sourceTableJDBCFetchSize                 ,
      ideaParallelDegree.intValue()            ,
      sparkParallelDegree.intValue()           ,
      sparkCNum                                ,
      sparkSNum                                )
    
    new MMC(s, x, r, mm)
  }
}