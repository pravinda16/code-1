package com.citi.sprinter.mm2hive

//  Author: Simon(jy44875) Time: 2017-05-17 ~ 2017-06-03

import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.DataFrame
import com.citi.sprinter.core._
import com.citi.sprinter.util._

class MNH(mmc: MMC) extends MMM(mmc) {
  def r(): Unit = {
    LG.info("In MNH")
    throw new SSE("not support in MemSQL") 
  }
}