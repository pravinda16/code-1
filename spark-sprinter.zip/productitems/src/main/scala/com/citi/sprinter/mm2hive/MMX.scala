package com.citi.sprinter.mm2hive

//  Author: Simon(jy44875) Time: 2017-05-20 ~ 2017-06-03

import org.apache.spark.sql.hive.HiveContext
import com.citi.sprinter.core._
import com.citi.sprinter.util._

object MMX {
  def fixCls(nzc: MMC, tba:String): String = {
    val fmtDt = nzc.x.sourceTableDateFormat
    val fmtTs = nzc.x.sourceTableTimestampFormat
    
    val ncols = nzc.mmcc.tbCols.map { c =>
      if(nzc.mmcc.dtCols.contains(c) && !fmtDt.isEmpty ) {
        s"DATE_FORMAT(${tba}.${c}, '${fmtDt.get}') AS ${c}"

      } else if (nzc.mmcc.tsCols.contains(c) && !fmtTs.isEmpty) {
        s"DATE_FORMAT(${tba}.${c}, '${fmtTs.get}') AS ${c}"   
      } else {
        s"${tba}.${c} AS ${c}"
      }
    }.mkString(",")
    
    LG.info(s"fmtDt: $fmtDt fmtTs: $fmtTs ")
    ncols
  }
  
  def newCls(x: SSXC): String = {
    val arr = x.sourceTableNewColumnsExpr.zip(x.sourceTableNewColumnsName).map(r => r._1 + " AS " + r._2)
    if (arr.length <= 0) "" else " , " + arr.mkString(" , ")
  }   
}