package com.citi.sprinter.nz2hive

//  Author: Simon(jy44875) Time: 2017-05-17 ~ 2017-05-20

import com.citi.sprinter.core._
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.DataFrame
import com.citi.sprinter.util._

class MNS(nzc: NZC) extends MNZ(nzc) {
  var cnt:Long=0
   
  def gc():String = {
    val where = if (fltexp.isEmpty) "" else s" WHERE ${fltexp.get}  "
    s"(SELECT COUNT(*) AS CNT FROM  $db.$tb T  $where ) y"
  }
  
  def gq(): String = {
    val where = if (fltexp.isEmpty) "" else s" WHERE ${fltexp.get}"
    val xcols = NZX.fixCls(nzc, "A")
    val ncols = NZX.newCls(nzc.x)
    s"( SELECT $xcols $ncols, MOD(DATASLICEID, $sparkpd) + 1 AS SPRINTER_ID  FROM  $db.$tb A $where ) X "    
  }

  def gd(dci: Array[STCI]): String = {
    val cs = dci.filter( TL.fTbCol(_)() ).map{ r => 
      "%-30s %s".format( TL.fixName(r.n), TL.fixAVRO(r.t, flfmt) )
    }.mkString(", \n")
    val tblfmt = TL.getTFD(flfmt)
    s"CREATE EXTERNAL TABLE $hivetb (\n $cs \n) $tblfmt LOCATION '$tbpath' "
  }
  
  def r(): Unit = {
    LG.info("In MNS")
    val sw = SW().start
    
    cnt = if(!unnest) 0 else {
      val cntjo = CUTL.getOption(nzc.s, gc(), 1000); LG.logSparkOption(cntjo)
      val dfcnt = ssc.read.format("jdbc").options(cntjo).load()
      val tbcnt = DF.getCnt(dfcnt)
      sw.info("SPRINTER CNT  time:", s"total cnt: $tbcnt ")
      tbcnt
    }
    
    val xo = CUTL.getXOption(sparkpd, 1, sparkpd + 1)
    val to = CUTL.getOption(nzc.s, gq(), jdbcfs)
    val jo = to ++ xo; LG.logSparkOption(jo)
    
    val df = ssc.read.format("jdbc").options(jo).load().cache()
    val tci = DS.getTCI(dsTCI, df, nzc)
    
    var bkl:String=""; val bkf =  unnest && HV.tbNotEmpty(ssc, hivetb)
    if(bkf) { var bkf = HV.bkETTable(ssc, hivetb); if( bkf.isEmpty) LG.error(s"Failed to backup table: $hivetb"); bkl=bkf.get }  

    val recon = DS.reconSrcWithDS(ssc, df, tci)
    if (!recon.succ) {
      if (!recon.inDSMT.isEmpty())      LG.error(recon.inDSMT)
      if (!recon.inHiveOrSrc.isEmpty()) LG.awpLog(recon.inHiveOrSrc)
    }
    ssc.sql(s"DROP TABLE IF EXISTS $hivetb"); val ddl = gd(tci); LG.debug(ddl); ssc.sql(ddl) //bugfix-24
    
    val dfh = ssc.sql(s"SELECT * FROM $hivetb LIMIT 1 "); val rrr = DS.reconTableSchema(df, dfh); LG.awpLog(rrr); dfh.unpersist()
    if( !rrr.isEmpty() ) { LG.error(rrr) }
    
    try {
      DF.save(df, tbpath, flfmt, tci.map(r => r.n)); df.unpersist()
      if(unnest) {
        LG.awpStat(s"$cnt"); LG.awpFileIds( HV.getHdfsFiles(ssc, tbpath));
      }
    } catch {
      case ex: Exception => { if(bkf) HV.rsETTable(ssc, hivetb, bkl); throw ex }
    }
    
    //keep data for filter
    if(bkf) {
      if( cnt == 0 && !fltexp.isEmpty ) {
        HV.rsETTable(ssc, hivetb, bkl)
      } else {
        HV.rmETTableBk(ssc, bkl, hivetb)
      }
    } 
  }
}