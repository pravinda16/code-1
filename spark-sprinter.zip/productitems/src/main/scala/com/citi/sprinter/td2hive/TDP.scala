package com.citi.sprinter.td2hive

//  Author: Simon(jy44875) Time: 2017-01-18   ~ 2017-05-10

import java.sql.{Connection,DriverManager}
import com.citi.sprinter.core._
import com.citi.sprinter.util._
import org.apache.spark.{ SparkContext, SparkConf }
import org.apache.spark.sql.hive.HiveContext

class TDP(s: SSSC, x: SSXC) extends TETLP{
  val db = s.sourceTable.split("\\.")(0).toUpperCase()
  val tb = s.sourceTable.split("\\.")(1).toUpperCase()
  var udb= db
  var utb= tb
  var utabs:Array[String]=Array.empty[String]
  
  def createDC() :Connection = {
    val driver = "com.teradata.jdbc.TeraDriver"
    var connection: Connection = null
    var times = 0
    var flag = 0

    while ( times <= 3 && flag == 0) {
      try {
        Class.forName(driver)
        times = times + 1
        connection = DriverManager.getConnection(s.sourceDatabaseURL, s.sourceDatabaseUser, s.sourceDatabasePassword.get) 
        flag = flag + 1
      } catch {
        case e: Exception => e.printStackTrace
      } 
    }
    
    if( flag > 0 ) connection else throw new SSE("Failed to connect to source data")
  }
  
  def checkTE(conn: Connection, ckdb:String, cktb:String): Boolean = {
    var tk: String  = ""
    var rt: String  = ""
    val sql = s"""
SELECT
  TABLEKIND, REQUESTTEXT
FROM DBC.TABLES 
WHERE DATABASENAME = '$ckdb' AND TABLENAME  = '$cktb'   """
    
    LG.debug(sql)
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        tk = rs.getString("TABLEKIND"); rt = rs.getString("REQUESTTEXT").replaceAll("\n", " ").replaceAll("\r", " ").replaceAll(";", ""); LG.debug(s"tk: $tk rt: $rt")
      }
      rs.close()
      
      val idxfrom = rt.indexOf("FROM")
      rt  = if(idxfrom >=0) rt.substring(idxfrom) else rt
      
      val regwhere = "^(.*)\\s+WHERE\\s+.*$".r
      rt= regwhere.replaceAllIn(rt, "$1")
      
       LG.info(s"rt: $rt")
       
      val te = if (tk == "V" && !rt.isEmpty()) {
        val fkdb    = ckdb.replace("_V", "_T")
        
        //database.table [alias]
        val regxxx  = "FROM\\s+(\\S+)\\.(\\S+)\\s*(\\S*)$".r
        val xdbname = regxxx.replaceAllIn(rt, "$1")
        val xtbname = regxxx.replaceAllIn(rt, "$2")
        LG.info(s"xtbname: $xtbname, xdbname: $xdbname")
        
        //table only
        val regtab  = "FROM\\s+([^\\s\\.]+)\\s*$".r
        val tonly   = regtab.replaceAllIn(rt, "$1")
        LG.info(s"tonly: $tonly, fkdb: $fkdb ")
        
        val kind = if( xdbname!= rt && xtbname != rt ) 1 else if (tonly != rt) 2 else -1
        udb = if ( kind == 1 ) xdbname  else fkdb
        utb = if ( kind == 1 ) xtbname  else tonly
        utabs=Array[String](utb)
        LG.info(s"kind: $kind, udb: $udb, utb: $utb rt: $rt")
        
        if (kind > 0) checkTE(conn, udb, utb) else {
          val xxx = rt.split("\\s+").filter( x => x.indexOf(".") > 0 && x.indexOf(".") < x.length() - 1 )
          val fnd = fkdb + "."
          val yyy = xxx.filter( _.contains(fnd) )
          
          if( yyy.size > 0 ) {
            val tmp = yyy(0)
            udb = tmp.split("\\.")(0)
            utb = tmp.split("\\.")(1)
            LG.info(s"kind: 3, udb: $udb, utb: $utb rt: $rt")
          } else if( xxx.size > 0 ) {
            val tmp = xxx(0)
            udb = tmp.split("\\.")(0)
            utb = tmp.split("\\.")(1)
            LG.info(s"kind: 4, udb: $udb, utb: $utb rt: $rt")
          } else {
            throw new SSE(s"HINT: set sourceUnderlyingTable in DSMT. Unable to get underlying table from view, except 'FROM under_db.under_tb', get ${rt} ")
          }
          true
        }
      } else { 
        !tk.isEmpty()
      }
      te
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw e
      }
    }
  }
    
  def getTS(conn: Connection): Int = {
    var mb: Int = 0
    val sql = s"""
SELECT
  ROUND(SUM(CURRENTPERM)/1024/1024,0) AS MB
FROM DBC.ALLSPACE 
WHERE DATABASENAME = '$udb' AND TABLENAME  = '$utb'   """
    LG.debug(sql)
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        mb = rs.getInt("MB")
      }
      rs.close()
      mb * 8
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get table size, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }
 
  def getTCols(conn: Connection): Array[String] = {
    var cols = scala.collection.mutable.ArrayBuffer.empty[String]
    val sql = s"""
SELECT COLUMNNAME 
FROM DBC.COLUMNS 
WHERE DATABASENAME = '$db' AND TABLENAME  = '$tb'
ORDER BY COLUMNID  """
    LG.debug(sql)
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        cols += rs.getString("COLUMNNAME").trim()
      }
      rs.close()
      cols.toArray
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get table cols, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }
  
  def getTDateCols(conn: Connection): Array[String] = {
    var cols = scala.collection.mutable.ArrayBuffer.empty[String]
    val tabs = utabs.map( "'" + _ + "'").mkString(",")
    val sql = s"""
SELECT DISTINCT COLUMNNAME 
FROM DBC.COLUMNS 
WHERE DATABASENAME = '$udb' AND TABLENAME  IN ( $tabs ) AND COLUMNTYPE IN ( 'DA' ) 
ORDER BY COLUMNID  """
    LG.debug(sql)  //null?
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        cols += rs.getString("COLUMNNAME").trim()
      }
      rs.close()
      cols.toArray
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get table size, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }

  def getTTimestampCols(conn: Connection): Array[String] = {
    var cols = scala.collection.mutable.ArrayBuffer.empty[String]
    val tabs = utabs.map( "'" + _ + "'").mkString(",")
    val sql = s"""
SELECT DISTINCT COLUMNNAME 
FROM DBC.COLUMNS 
WHERE DATABASENAME = '$udb' AND TABLENAME IN ( $tabs ) AND COLUMNTYPE IN ( 'TS', 'SZ' ) 
ORDER BY COLUMNID  """
    LG.debug(sql) //null?
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        cols += rs.getString("COLUMNNAME").trim()
      }
      rs.close()
      cols.toArray
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get table size, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }
  
  def getNumOfNodes(conn: Connection): Int = {
    var cnt: Int = 0
    val sql = "SELECT count(distinct nodeid) as CNT FROM dbc.ResCpuUsageByAmpView "
    LG.debug(sql)
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        cnt = rs.getInt("CNT")
      }
      rs.close()
      cnt
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get table size, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }
  
  
   def getPKI(conn: Connection): Option[String] = {
    val arr = scala.collection.mutable.ArrayBuffer[String]()
    val sql = s"""
SELECT COLUMNNAME,  COLUMNPOSITION
FROM DBC.INDICESV  
WHERE DATABASENAME = '$udb' AND TABLENAME = '$tb' AND (INDEXTYPE IN ('P', 'Q'))
ORDER BY COLUMNPOSITION """
    LG.debug(sql)
    
    try {
      val statement = conn.createStatement
      val rs = statement.executeQuery(sql)
      while (rs.next) {
        arr += rs.getString("COLUMNNAME")
      }
      rs.close()
      if( arr.size > 0) Some( arr.mkString(",")) else None
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get table information 1, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }

   def getDPKI(conn: Connection): Option[String] = {
    val arr = scala.collection.mutable.ArrayBuffer[String]()
    
    //AND COLUMNTYPE IN( 'D', 'I8', 'CV', 'CF' ) 
    val sql1 = s"""
SELECT TOP 3 COLUMNNAME
FROM   DBC.COLUMNSV
WHERE  DATABASENAME = '$db' AND TABLENAME = '$tb' AND COLUMNNAME LIKE '%ID%' """ 

    val sql3 = s"""
SELECT TOP 3 COLUMNNAME
FROM   DBC.COLUMNSV
WHERE  DATABASENAME = '$db' AND TABLENAME = '$tb' """

    try {
      val statement = conn.createStatement
      
      LG.debug(sql1)
      val rs1 = statement.executeQuery(sql1)
      while (rs1.next) {
        arr += rs1.getString("COLUMNNAME")
      }
      rs1.close()

        LG.debug(sql3)
        val rs3 = statement.executeQuery(sql3)
        while (rs3.next && arr.size < 3) {
          arr += rs3.getString("COLUMNNAME")
        }
        rs3.close()
      
      if( arr.size > 0) Some( arr.mkString(",")) else None
    } catch {
      case e: Exception => {
        e.printStackTrace
        throw new SSE(s"unable to get table information 2, ${db}.${tb}, error: ${e.toString()}")
      }
    }
  }
  
  def tbqq(tabPIC: String) : String  ={
    s"""
SELECT
  COUNT(*)       AS NUMAMP,
  SUM(A.AMPROWS) AS TABRNUM,
  MIN(A.AMPROWS) AS AMPMIN,
  MAX(A.AMPROWS) AS AMPMAX,
  AVG(A.AMPROWS) AS AMPAVG,
  ROUND(100 - ( AVG(A.AMPROWS)/MAX(A.AMPROWS) * 100 ), 0) AS TABSKEW
FROM ( 
 SELECT
  HASHAMP(HASHBUCKET(HASHROW($tabPIC))) AS AMPID, COUNT(*) AS AMPROWS
 FROM 
  $db.$tb
 GROUP BY 1
) A
"""   
  }
  
  def getTDCC(): TDCC = {
    val sw = SW().start
    val conn    = createDC()
    sw.debug("TDCC createDC")
    
    val sourceUnderlyingTable = CUTL.getOptionalArg(CUTL.argm, "sourceUnderlyingTable")
    if( sourceUnderlyingTable.isEmpty ) {
      if (!checkTE(conn, db, tb)) {
        conn.close()
        throw new SSE(s"table does not exists or underlying table does not exist: $tb ")
      }
    } else {
        val strArr = sourceUnderlyingTable.get.split("\\.")
        if (strArr.length != 2) {
          throw new SSE(s"invalid sourceUnderlyingTable, excepted db.table get ${sourceUnderlyingTable}")
        }
        udb=strArr(0)
        utb=strArr(1)
    }
    
    sw.debug("TDCC checkTE")

    val numNodes   = getNumOfNodes(conn)
    sw.debug("TDCC getTS")
    
    val tabMB   = getTS(conn)
    sw.debug("TDCC getTS")
    
    val tabpki  = getPKI(conn)
    sw.debug("TDCC getPKI")
    
    val tabPIC  = if (!tabpki.isEmpty) tabpki.get else getDPKI(conn).get
    sw.info(s"TDCC tabPIC $tabPIC")
    
    val tbcols = getTCols(conn)
    val dtCols = getTDateCols(conn)
    val tsCols = getTTimestampCols(conn)
    
    val tmpdt=dtCols.mkString(","); val tmpts=tsCols.mkString(",")
    LG.info(s"date_cols: $tmpdt, timestamp_cols: $tmpts") 

    var tabSkew: Int = 0
    var tabRNum: Long = 0
    var numAMP:  Int = 0
    var ampMin:  Int = 0
    var ampMax:  Int = 0
    var ampAvg:  Int = 0
    
    val sql  = tbqq(tabPIC)
    LG.debug(s"sql: $sql") 
    
    try {
      val statement = conn.createStatement
      LG.debug(sql)
      val rs = statement.executeQuery(sql)
      while (rs.next) {
       tabSkew = rs.getInt("TABSKEW")
       tabRNum = rs.getLong("TABRNUM")
       numAMP  = rs.getInt("NUMAMP")
       ampMin  = rs.getInt("AMPMIN")
       ampMax  = rs.getInt("AMPMAX")
       ampAvg  = rs.getInt("AMPAVG")
      }
      rs.close()
      
      sw.debug("TDCC TDCC")
      
      TDCC(numNodes, tabMB, tabRNum, tabSkew, tabPIC, numAMP, ampMin, ampMax, ampAvg, tbcols, dtCols, tsCols,  0, false)
    } catch {
      case e: Exception => {
        throw new SSE(s"unable to get table information, ${db}.${tb}, error: ${e.toString()}")
        throw e
      }
    }
  }
 
  def p(): TDC = {
    val td = getTDCC()
    LG.debug(td.toString())

    val mb = td.tabMB.toInt
    val amb = Array[Int](64,  1024, 8*1024, 1024*16, 1024*64, 1024 *512, 1024 * 1024, 8 * 1024* 1024, 32 * 1024* 1024,Int.MaxValue)
    val spd = Array[Int](4,   8,    16,          32, 64,      128,        256,         512,            1024,           2048)
    val ccc = Array[Int](1,   2,    4,           4,  2,       2,          1,           1,              1,              1)
    val ddd = Array[Int](2,   2,    4,           8,  16,      16,         24,          24,             24,             24)
    val eee = Array[Int](2,   4,    8,          16,  16,      16,         16,          16,             16,             16)

    val sparkDriverMemory                     = TL.getOrFindTable("SPRINTER_X_DRIVER_MEMORY",    amb, ddd, mb)
    if( !CUTL.getOptionalEnv("SPRINTER_GET_DRIVER_MEMORY").isEmpty ) {
      println(s"ROWROW_DMM $sparkDriverMemory")
      System.exit(0)
    }
    
    val _sparkParallelDegree                  = CUTL.getOptionalEnvx("sparkParallelDegree").getOrElse("0").toInt
    
    val sparkMaxParallelDegree                = CUTL.getOptionalEnvx("SPRINTER_X_MAX_PARALLEL").getOrElse("64").toInt    
    val sparkExecutorCores                    = TL.getOrFindTable("SPRINTER_X_EXECUTOR_CORES",   amb, ccc, mb)
    val sparkExecutorMemory                   = TL.getOrFindTable("SPRINTER_X_EXECUTOR_MEMORY",  amb, eee, mb)
    val sourceTableJDBCFetchSize              = CUTL.getOptionalEnvx("SPRINTER_X_JDBC_FETCH_SIZE").getOrElse("10000").toInt
    val spark_colsotre_batch_size             = CUTL.getOptionalEnvx("SPRINTER_X_COLUMNARSTORAGE_BATCHSIZE").getOrElse("100000").toLong
          
    val sparkConf = new SparkConf()
    sparkConf.setAppName("SPRINTER_" + s.sprinterJobID + "_" + s.sprinterRunID)
    sparkConf.set("spark.driver.memory",                           s"${sparkDriverMemory}g")
    sparkConf.set("spark.executor.memory",                         s"${sparkExecutorMemory}g")
    sparkConf.set("spark.executor.cores",                          sparkExecutorCores.toString)
    sparkConf.set("spark.sql.inMemoryColumnarStorage.batchSize",   spark_colsotre_batch_size.toString)
    sparkConf.set("spark.ui.enabled",                              "false")
    sparkConf.set("spark.shuffle.memoryFraction",                  "0.5")
    sparkConf.set("spark.yarn.executor.memoryOverhead",            "4096")

    val instances = CUTL.getOptionalEnv("SPRINTER_X_EXECUTOR_INSTANCES")
    if (!instances.isEmpty) {
      sparkConf.set("spark.executor.instances", instances.get)
    }

    val sc  = new SparkContext(sparkConf)
    val sparkSSC = new HiveContext(sc)
    sparkSSC.setConf("spark.sql.parquet.compression.codec", x.targetTablecompressCodec)
    if( !s.targetTablePartitionColumn.isEmpty) HV.enableDP(sparkSSC)
    CTRK.inited()
  

    var sparkCNum:Int = 1
    var sparkSNum:Int = 0    
    if (td.ampMax > 0L) {
      val sz = 1000
      val xcols = td.tbCols.map( x => x + " AS " + x ).mkString(",")
      val sql = s"( SELECT $xcols FROM $db.$tb SAMPLE $sz) A"
      val to = CUTL.getOption(s, sql, sourceTableJDBCFetchSize); LG.logSparkOption(to)
      val df = sparkSSC.read.format("jdbc").options(to).load()
      val rdd = df.rdd.map(_.toString())
      val aa = rdd.map(_.getBytes("UTF-8").length.toLong).reduce(_ + _) / sz
      val bb    = math.max(((aa * td.ampMax ) >> 20), 1)
      sparkCNum = math.max(1024/bb,   1).intValue()
      sparkSNum = math.ceil(bb /1024.0).intValue()
    }
    
    val ideaParallelDegree  = if( sparkSNum > 1) td.numAMP * sparkSNum else math.max(td.numAMP/sparkCNum,1)
    val sparkParallelDegree = if( _sparkParallelDegree > 0 ) _sparkParallelDegree else math.min( math.min(TL.findTab(amb, spd, mb), td.numNodes/4*16), sparkMaxParallelDegree) 
    
    LG.info(s"sparkExecutorCores: $sparkExecutorCores g; sparkExecutorMemory: $sparkExecutorMemory table: $mb MB")
    LG.info(s"numAMP: ${td.numAMP} sparkCNum: $sparkCNum; sparkSNum: $sparkSNum ideaParallelDegree: $ideaParallelDegree sparkParallelDegree: $sparkParallelDegree")
    
    val r = SSRC(
      sc                                       ,
      sparkSSC                                 ,
      sparkMaxParallelDegree                   ,
      sparkDriverMemory                        ,
      sparkExecutorCores                       ,
      sparkExecutorMemory                      ,
      sourceTableJDBCFetchSize                 ,
      ideaParallelDegree                       ,
      sparkParallelDegree                      ,
      sparkCNum                                ,
      sparkSNum                                )
    
    new TDC(s, x, r, td)
  }
}