package com.citi.sprinter.td2hive

//  Author: Simon(jy44875) Time: 2017-01-24 ~ 2017-05-29

import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.DataFrame
import scala.collection.mutable.ArrayBuffer
import com.citi.sprinter.core._
import com.citi.sprinter.util._

class MNL(tdc: TDC) extends MTD(tdc) {
  var cnt:Long=0
 
  def gc():String = {
    val where = if (fltexp.isEmpty) "" else s" WHERE ${fltexp.get}  "
    s"(SELECT COUNT(*) AS CNT FROM  $db.$tb T  $where ) y"
  }
  
  def gq(): Array[(String, Int)] = {
    val pic = tdc.tdcc.tabPIC; val cond = if (fltexp.isEmpty) "" else s" AND  ${fltexp.get}  "
    val xcols = TDX.fixCls(tdc, "A"); val ncols = TDX.newCls(tdc.x)
    
    val nn = ampn + 1
    val a1 = 1 to (ampn + 1, tdc.r.sparkCNum); val a2 = a1.slice(1, a1.length) :+ ( a1(a1.length-1) + 1 )
    val aa = a1.zip(a2).toArray
    
    val ids = TL.genid(aa.length, (1 to sparkpd).toArray)
    val pks = TL.genpk(aa.length, sparkpd); var k = -1  
    val sqls = aa.grouped(sparkpd).map { x =>
      val stat = x.map { y =>
        val ll = y._1; val rr = y._2; k=k+1; val id = ids(k); val pk = pks(k); 
        val q = s"SELECT T.*, $id AS SPRINTER_ID,  '$pk' AS SPRINTER_PTK FROM  $db.$tb T WHERE ( (HASHAMP(HASHBUCKET(HASHROW($pic))) MOD $nn ) + 1 >= $ll AND (HASHAMP(HASHBUCKET(HASHROW($pic))) MOD $nn ) + 1 < $rr)  $cond"
        q
      }
      val tt = stat.mkString(" UNION ALL \n") 
      val rt = (s"( SELECT $xcols $ncols, A.SPRINTER_ID,  A.SPRINTER_PTK FROM ( $tt ) A ) y", x.length)
      rt
    }
   sqls.toArray
  }

  def gd(dci: Array[STCI]): String = {
    val cs = dci.filter( TL.fTbCols(_)(Array("SPRINTER_ID", "SPRINTER_PTK")) ).map{ r => 
      "%-30s %s".format( r.n, TL.fixAVRO(r.t, flfmt) )
    }.mkString(", \n")
    val tblfmt = TL.getTFD(flfmt)
    s"CREATE EXTERNAL TABLE $hivetb (\n $cs \n) PARTITIONED BY (SPRINTER_PTK STRING) $tblfmt LOCATION '$tbpath' "
  }
  
  def u(): Unit = {
    var kk = 0
    val qq = gq()
    val sw = SW().start
    var nl : Array[String] = null

    cnt = if(!unnest) 0 else {
      val cntjo = CUTL.getOption(tdc.s, gc(), 1000); LG.logSparkOption(cntjo)
      val dfcnt = ssc.read.format("jdbc").options(cntjo).load()
      val tbcnt = DF.getCnt(dfcnt)
      sw.info("SPRINTER CNT  time:", s"total cnt: $tbcnt ")
      tbcnt
    }
    
    val total=qq.length
    qq.map { x =>
      kk     = kk + 1; val q = x._1; val apd = x._2;
      sw.info("SPRINTER CNT  time:", s"total: $total, current: $kk ")
      
      //2017-09-07
      if (kk == 1) {
        val dtfinding=DS.reconDSDate(tdc, db, tb)
        if( !dtfinding.isEmpty() ) { LG.error(dtfinding) }
      }
      
      val xo = CUTL.getXOption(apd, 1, apd + 1)
      val to = CUTL.getOption(tdc.s, q, jdbcfs)
      val jo = to ++ xo; LG.logSparkOption(jo)   
      val df = ssc.read.format("jdbc").options(jo).load().cache() 
      if (kk == 1) {
        val tci = DS.getTCI(dsTCI, df, tdc)
        nl = tci.map(r=>r.n)

        val recon = DS.reconSrcWithDS(ssc, df, tci)
        if (!recon.succ) {
          if (!recon.inDSMT.isEmpty())      LG.error(recon.inDSMT)
          if (!recon.inHiveOrSrc.isEmpty()) LG.awpLog(recon.inHiveOrSrc)
        }
        ssc.sql(s"DROP TABLE IF EXISTS $hivetb"); val ddl = gd(tci); LG.debug(ddl); ssc.sql(ddl) //bugfix-24
        
        val dfh = ssc.sql(s"SELECT * FROM $hivetb LIMIT 1 "); val rrr = DS.reconTableSchema(df, dfh); LG.awpLog(rrr); dfh.unpersist()
        if( !rrr.isEmpty() ) { LG.error(rrr) }
      }
      
      val np=s"$tbpath/sprinter_ptk=$kk"
      DF.save(df, np, flfmt, nl); df.unpersist();
      if(unnest) {
        LG.awpFileIds( HV.getHdfsFiles(ssc, np));
      }
    }
    
    ssc.sql(s"MSCK REPAIR TABLE $hivetb")
    if(unnest) LG.awpStat(s"$cnt")
  }

  def r(): Unit = {
    LG.info("In MNL")
     
    var bkl: String = ""; val bkf =  unnest && HV.tbNotEmpty(ssc, hivetb)
    if(bkf) { var bkf = HV.bkETTable(ssc, hivetb); if( bkf.isEmpty) LG.error(s"Failed to backup table: $hivetb"); bkl=bkf.get } 
    try {
      u()
    } catch {
      case ex: Exception => { if(bkf) HV.rsETTable(ssc, hivetb, bkl); throw ex }
    }
    
    //keep data for filter
    if(bkf) {
      if( cnt == 0 && !fltexp.isEmpty ) {
        HV.rsETTable(ssc, hivetb, bkl)
      } else {
        HV.rmETTableBk(ssc, bkl, hivetb)
      }
    }
  }  
}