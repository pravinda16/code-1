package com.citi.sprinter.td2hive

//  Author: Simon(jy44875) Time: 2017-01-18

import com.citi.sprinter.core._

case class TDCC (
    val numNodes:  Int,
    val tabMB:     Int,
    val tabRNum:   Long,
    val tabSkew:   Int,
    val tabPIC:    String,    
    val numAMP:    Int,
    val ampMin:    Int,
    val ampMax:    Int,
    val ampAvg:    Int,
    val tbCols:    Array[String],
    val dtCols:    Array[String],
    val tsCols:    Array[String],
    val depth:     Int,
    val flBkF:     Boolean
);

case class TDC(override val s:SSSC,  override val x:SSXC, override val r:SSRC, val tdcc: TDCC) extends SSBC(s, x, r)