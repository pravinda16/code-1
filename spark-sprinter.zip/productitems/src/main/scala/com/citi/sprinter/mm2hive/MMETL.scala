package com.citi.sprinter.mm2hive

//  Author: Simon(jy44875) Time: 2017-05-20 ~ 2017-06-03

import com.citi.sprinter.core._
import com.citi.sprinter.util._
import java.text.SimpleDateFormat
import java.util.Calendar

abstract class MMM(mmc: MMC) extends TETLM {
  val ssc    = mmc.r.sparkSSC
  val db     = mmc.s.sourceTable.split("\\.")(0)
  val tb     = mmc.s.sourceTable.split("\\.")(1)
  val fltexp = mmc.x.sourceTableFilterExpr
  val hivedb = mmc.s.targetTable.split("\\.")(0).toLowerCase()
  val hivetb = mmc.s.targetTable.split("\\.")(1).toLowerCase()
  val dbpath = mmc.s.targetTableLocation.getOrElse( HV.getDBFolder(ssc, hivedb) ) 
  val tbpath = s"$dbpath/$hivetb"
  val flfmt  = mmc.s.targetTableFileFormat
  val partnn = mmc.mmcc.partNum.intValue
  val ideapd = mmc.r.ideaParallelDegree
  val sparkpd= mmc.r.sparkParallelDegree.toInt
  val jdbcfs = mmc.r.sourceTableJDBCFetchSize
  val dsTCI  = DS.getTCI(mmc)
  val retenp = mmc.s.targetTablePartitionRetentionPolicy
  val unnest = mmc.mmcc.depth == 0
  val flBkF  = mmc.mmcc.flBkF
  val nodataE =  if( !mmc.x.sourceTableDisableNoDataException.isEmpty && mmc.x.sourceTableDisableNoDataException.get == "ON") false else true

  def dumpMMCC(inf:Boolean, flbak:Boolean): MMCC = {
    val nbakf=if(inf) mmc.mmcc.flBkF else flbak
    MMCC(
      mmc.mmcc.tabBK,
      mmc.mmcc.tabMB,
      mmc.mmcc.partSkew,
      mmc.mmcc.partMin,
      mmc.mmcc.partMax,
      mmc.mmcc.partAvg,
      mmc.mmcc.partNum,
      mmc.mmcc.aggNum,
      mmc.mmcc.tbCols,
      mmc.mmcc.dtCols,
      mmc.mmcc.tsCols,
      mmc.mmcc.depth + 1, nbakf)
  }
  
  def getMinYMD(): String = {
      val fmtYMD = new SimpleDateFormat("yyyy-MM-dd")
      val cal = Calendar.getInstance(); cal.setTime(fmtYMD.parse(mmc.s.sprinterAsOfDate)); cal.add(Calendar.DATE, -1 * (retenp-1).intValue)
      val mindt=cal.getTime;val minYMD=fmtYMD.format(mindt)
      minYMD
  }

 def cleanExpiredData(ptkl: String) = {
    if(!flBkF && retenp > 0L && HV.tbNotEmpty(ssc, hivetb)) {
      val fmtYMD = new SimpleDateFormat("yyyy-MM-dd"); val minYMD = getMinYMD(); val mindt  = fmtYMD.parse(minYMD)
      val fixdates  = HV.getExpiredDate(ssc, hivetb, ptkl, minYMD)  //01    
      val dfprts = ssc.sql(s"SHOW PARTITIONS $hivetb").collect()
      
      //clean up
      dfprts.map{ row =>
        val pts=row.get(0).toString(); val ptvYMD=HT.getYMDFromPTS(ptkl, pts);  val dtYMD = TL.tryParse(fmtYMD, ptvYMD)      
        if( dtYMD.before(mindt) ) {
          HV.rmHDFSFolder(ssc, s"$tbpath/$pts")
          val hiveptexpr = HT.getPTEFromPTS(pts); val sqldrop = s"ALTER TABLE $hivetb DROP IF EXISTS PARTITION ($hiveptexpr)"
          LG.info(s"minYMD: $minYMD, ptvYMD: $ptvYMD sqldrop: $sqldrop");ssc.sql(sqldrop)         
        }else {
          LG.info(s"minYMD: $minYMD, ptvYMD: $ptvYMD keep $pts")
        }
      }
 
      //clean up fix 02
      LG.info( s"minYMDx: $minYMD, dates:" + fixdates.mkString(",") )
      dfprts.map{ row =>
        val pts=row.get(0).toString(); val ptvYMD=HT.getYMDFromPTS(ptkl, pts);  val dtYMD = TL.tryParse(fmtYMD, ptvYMD)    
        if( dtYMD.before(mindt)  && fixdates.indexOf(ptvYMD) >= 0 ) {
          val expr = s"${ptkl}=${ptvYMD}"; val indx = pts.indexOf(expr)
          LG.info(s"expr: $expr, pts: $pts ")
          if( indx >= 0) {
            val path=pts.substring(0, indx + expr.length )
            val hdfspath = s"$tbpath/$path"; LG.info(s"minYMDx: $minYMD, ptvYMD: $ptvYMD, hdfspath: $hdfspath ")
            HV.rmHDFSFolder(ssc, hdfspath)
          }       
        }
      }
    } 

  }// end cleanExpiredData
}


class MMETL(s: SSSC, x: SSXC) extends TETLS {
  val tb     = s.sourceTable.split("\\.")(1).toUpperCase()
  val hivedb = s.targetTable.split("\\.")(0).toLowerCase()
  val hivetb = s.targetTable.split("\\.")(1).toLowerCase()

  def getm(mmc: MMC): TETLM = {
    val rp = mmc.s.targetTablePartitionRetentionPolicy
    val mm = if (s.targetTablePartitionColumn.isEmpty) {
      if( mmc.r.sparkParallelDegree >= mmc.r.ideaParallelDegree) new MNS(mmc) else {
        if( mmc.r.sparkSNum > 1 ) new MNH(mmc) else new MNL(mmc)
      }
    } else {
      if( !HV.tbExists(mmc.r.sparkSSC, hivetb) || HV.tbNoData(mmc.r.sparkSSC, hivetb) ) {
        LG.info("TDETL table not exists or table emtpy"); new MPCore(mmc) 
      }else {
        val ls = mmc.x.targetTableLoadingStrategory
        val ss = mmc.x.sourceTableNewColumnsName.filter( r => r.toUpperCase() == mmc.s.targetTablePartitionColumn.get.toUpperCase ).length == 1 
         
        if( ls == "FULL_LOADING" && rp == 0L ) {
          LG.info("TDETL MPF FULL_LOADING");           new MPDFull(mmc)
        }else if ( !ss && ls == "INCREMENTAL_LOADING_CNT"){
           LG.info("TDETL INCREMENTAL_LOADING_CNT");   new MPDCnt(mmc)
        }else if ( ls == "TRUNCATE_LOADING"){
           LG.info("TDETL TRUNCATE_LOADING");          new MPDDrp(mmc)
        }else{
          LG.info("TDETL DEFAULT");                    new MPCore(mmc)
        }
      }
    }
    mm
  }

  def r() = {
    val sw = SW().start
    val mmc = new MMP(s, x).p()
    sw.awpLog("SPRINTER INIT time:")

    mmc.r.sparkSSC.sql(s"USE  $hivedb")
    val m = getm(mmc)
    m.r()

    val benchmark=50; val speed=mmc.mmcc.tabMB/sw.seconds(); val ratio= math.ceil(100.0 * ( speed-benchmark ) / benchmark)
    val sx = s"speed: $speed mb/s (benchmark: $benchmark, ration: ${ratio}%), table: $tb, partNum: ${mmc.mmcc.partNum},table_size: ${mmc.mmcc.tabMB} MB ,parallel: ${mmc.r.sparkParallelDegree}, file_format: ${mmc.s.targetTableFileFormat}"
    sw.awpLog("SPRINTER ETL  time:", sx )
    
    CTRK.ended()
    mmc.r.sc.stop()
  }
  
}