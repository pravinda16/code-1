package com.citi.sprinter.td2hive

import org.apache.spark.sql.hive.HiveContext
import com.citi.sprinter.core._
import com.citi.sprinter.util._

//  Author: Simon(jy44875) Time: 2017-09-19

object TDX {  
  def fixCls(tdc: TDC, tba:String): String = {
    val fmtDt = tdc.x.sourceTableDateFormat
    val fmtTs = tdc.x.sourceTableTimestampFormat
    
    val dtCols1 = DS.getDTColsFromDS(tdc); val tsCols1 = DS.getTSColsFromDS(tdc)
    val dtCols  = if ( dtCols1.isEmpty ) tdc.tdcc.dtCols else dtCols1; val tsCols  = if ( tsCols1.isEmpty ) tdc.tdcc.tsCols else tsCols1
    val trCols  = DS.getTrimColsFromDS(tdc)
    
    val ncols = tdc.tdcc.tbCols.map { c =>
      if(dtCols.contains(c) && !fmtDt.isEmpty ) {
        s"TO_CHAR(${tba}.${c}, '${fmtDt.get}') AS ${c}"

      } else if (tsCols.contains(c) && !fmtTs.isEmpty) {
        s"TO_CHAR(${tba}.${c}, '${fmtTs.get}') AS ${c}"   
      } else {
        if (trCols.contains(c)) s"TRIM( ${tba}.${c} ) AS ${c}" else s"${tba}.${c} AS ${c}"
      }
    }.mkString(",")
    
    LG.info(s"fmtDt: $fmtDt fmtTs: $fmtTs ")
    ncols
  }
  
  def newCls(x: SSXC): String = {
    val arr = x.sourceTableNewColumnsExpr.zip(x.sourceTableNewColumnsName).map(r => r._1 + " AS " + r._2)
    if (arr.length <= 0) "" else " , " + arr.mkString(" , ")
  }   
}