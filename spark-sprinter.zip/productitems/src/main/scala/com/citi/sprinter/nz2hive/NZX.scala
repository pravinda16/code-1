package com.citi.sprinter.nz2hive

//  Author: Simon(jy44875) Time: 2017-05-17 ~ 2017-05-18

import org.apache.spark.sql.hive.HiveContext
import com.citi.sprinter.core._
import com.citi.sprinter.util._

object NZX {
  def fixCls(nzc: NZC, tba:String): String = {
    val fmtDt = nzc.x.sourceTableDateFormat
    val fmtTs = nzc.x.sourceTableTimestampFormat
    
    val ncols = nzc.nzcc.tbCols.map { c =>
      if(nzc.nzcc.dtCols.contains(c) && !fmtDt.isEmpty ) {
        s"TO_CHAR(${tba}.${c}, '${fmtDt.get}') AS ${c}"

      } else if (nzc.nzcc.tsCols.contains(c) && !fmtTs.isEmpty) {
        s"TO_CHAR(${tba}.${c}, '${fmtTs.get}') AS ${c}"   
      } else {
        s"${tba}.${c}"
      }
    }.mkString(",")
    
    LG.info(s"fmtDt: $fmtDt fmtTs: $fmtTs ")
    ncols
  }
  
  def newCls(x: SSXC): String = {
    val arr = x.sourceTableNewColumnsExpr.zip(x.sourceTableNewColumnsName).map(r => r._1 + " AS " + r._2)
    if (arr.length <= 0) "" else " , " + arr.mkString(" , ")
  }   
}